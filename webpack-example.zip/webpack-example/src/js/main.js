import $ from "jquery";
import "../scss/main.scss";

console.log('test');
