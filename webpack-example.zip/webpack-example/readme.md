run
```
npm install
```